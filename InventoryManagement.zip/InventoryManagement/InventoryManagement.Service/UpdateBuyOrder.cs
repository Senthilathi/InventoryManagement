﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InventoryManagement.Service
{
    public class UpdateBuyOrder: OrderCommand 
    {
        public override void Execute(List<Item> stockItems, Item updateItem)
        {
            var item = stockItems.Where(X => X.Name == updateItem.Name).First();
            item.AvailableQuantity += updateItem.AvailableQuantity;

        }
    }
}
