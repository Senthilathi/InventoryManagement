﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InventoryManagement.Service
{
    public class UpdateSellOrder : OrderCommand 
    {
        public override void Execute(List<Item> stockItems, Item updateSellItem)
        {
            var item = stockItems.Where(X => X.Name == updateSellItem.Name && X.IsDelete ==false).First();
            item.ProfitAmount += (updateSellItem.AvailableQuantity * item.SellingPrice) - (updateSellItem.AvailableQuantity * item.BuyingPrice);
            item.AvailableQuantity -= updateSellItem.AvailableQuantity;
        }
    }
}
